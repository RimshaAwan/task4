
setTimeout(function(){
    document.getElementById("box").style.display="block"
  },5000)
  
  setTimeout(function(){
      document.getElementById("box").style.display="none"
    },10000)






function changebg(){
    let  navbar=document.getElementById('navbar');
    let scrollValue = window.scrollY;
    let sr=document.getElementById("sea");
    let phn=document.getElementById("ph");
    
    if(scrollValue > 200){
        navbar.classList.add('bgcol');
        sr.classList.add("sicon");
        phn.classList.add("picon");
        document.getElementById("whitelogo").src="./img/Capture-removebg-preview.png"
        
    }else{
        navbar.classList.remove('bgcol');
        sr.classList.remove("sicon");
        phn.classList.remove("picon");
        document.getElementById("whitelogo").src="./img/logo.png"
        
    }
}

window.addEventListener('scroll', changebg);




